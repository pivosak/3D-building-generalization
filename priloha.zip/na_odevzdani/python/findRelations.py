print "***************************************************"
print "****** Find relations for geometry table **********"
print "***************************************************"
print ""
from helpers import *


findRelations ("models", "vizu_orig_relations")