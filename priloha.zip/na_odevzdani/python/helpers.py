﻿import copy
import sys
import os
#make new line
#udelej novy radek
def newLine(str):
	str += "\n"
	return str


#make connection to database
#vytvor pripojeni k databazi
def doConn():
	import psycopg2
	from datetime import datetime
	##credentials for local connection
	dbname = "postgres"
	host="localhost"
	user = "python"
	psswrd = "abc"
	credentials = {'dbname': "postgres", 'host': "localhost", 'user': "python", 'psswrd': "abc"}
	start_tm = datetime.now()

	try:
		conn = psycopg2.connect(database=dbname, user=user, host=host, password=psswrd)
		print "Succefully connected to Postgres, DATABASE: " + dbname + " as USER: " + user
	except:
		print "I am unable to connect to the database"
	return conn, start_tm

#DROP database tableName
#Dropni databazovou tabulku
def dropTable(cur,tableName):
	sql = "DROP TABLE IF EXISTS "+str(tableName)+" ;"
	cur.execute(sql)

#Parse WKT 2D Polygon geometry
#Parsuj 2D Polygon geometrii ulozenou jako WKT
def parse2Dpoly(p):
	pList = []
	base = p.replace('POLYGON((','').replace('))','').split(',')
	for coor in base:
		vertex = []
		vertex.append( float(coor.split(' ')[0]) )
		vertex.append( float(coor.split(' ')[1]) )
		pList.append(vertex)
	return pList


#Pro dva body v1 a v2 vytvor svisly polygon (obdelnik), zmin - spodni vyska, zmax - horni vyska
#For given point v1 and v2 generate vertical polygon (rectangle), zmin - bottom height, zmax - upper height
def liftUp(v1,v2,zmin,zmax):
	v1min = copy.deepcopy(v1)
	v1min.append(zmin)
	v2min = copy.deepcopy(v2)
	v2min.append(zmin)
	v1max = copy.deepcopy(v1) 
	v1max.append(zmax)
	v2max = copy.deepcopy(v2)
	v2max.append(zmax)
	polygon = []
	polygon.append(v1min)
	polygon.append(v2min)
	polygon.append(v2max)
	polygon.append(v1max)
	polygon.append(v1min)
	return polygon

#Make WKT 3D Polygon from Python list of coordinates
#Generuj WKT 3D Polygon z Python seznamu souradnic
def listToPolyZ(p):
	begin='POLYGONZ(('
	first = True
	for v in p:
		if first:
			sep=''
			first = False
		else:
			sep=','
		begin += sep+str(v[0])+' '+str(v[1])+' '+str(v[2])
	return begin+'))'
	
import math
#Compute polygon orientation given list of ordered points
#Spocitej orientaci polygonu ze seznamu usporadanych bodu
def orientation(p):
	i=0
	o = None
	sum = 0
	for v in p:
		x1 = p[i][0]
		y1 = p[i][1]
		x2 = p[i+1][0]
		y2 = p[i+1][1]
		sum += (x1*y2 - x2*y1)
		if (i+1)==len(p):
			break
	o = math.copysign(1, sum)
	return o
	
def startProgress(title):
    global progress_x
    sys.stdout.write(title + ": [" + "-"*40 + "]" + chr(8)*41)
    sys.stdout.flush()
    progress_x = 0

def progress(x):
    global progress_x
    x = int(x * 40 // 100)
    sys.stdout.write("#" * (x - progress_x))
    sys.stdout.flush()
    progress_x = x

def endProgress():
    sys.stdout.write("#" * (40 - progress_x) + "]\n")
    sys.stdout.flush()
	
	
	
#################################################################################################
def findRelations (fromTable, toTable):
	from datetime import datetime
	conn=doConn() #pripojeni k dtb
	startTime = conn[1]
	conn = conn[0]
	cur = conn.cursor()

	if (fromTable == toTable):
		print "ERROR: identical From and To table names!"
	else:
		print "----------------------"
		print "Searching for topology relations in table: <" + fromTable + ">"
		print "Writing output to table: <" + toTable + ">"
		
		sql = """select id_bud from REPLACE_FROM_TABLE group by 1 order by 1;"""
		sql = sql.replace("REPLACE_FROM_TABLE", fromTable)
		cur.execute(sql)
		print "SELECT list of IDs finished"
		rows = cur.fetchall()
		
		#divide into smaller chunks
		n=1
		rows = [rows[i:i + n] for i in xrange(0, len(rows), n)]
		
		#print rows
		sql = """drop table if exists REPLACE_TO_TABLE ;"""
		sql = sql.replace("REPLACE_TO_TABLE", toTable)
		cur.execute(sql)
		print "DROP finished"
		
		sql = """create table REPLACE_TO_TABLE (id_bud_1 int, id_bud_2 int, topo_element_dim int, geomtype varchar(40));"""
		sql = sql.replace("REPLACE_TO_TABLE", toTable)
		cur.execute(sql)
		print "CREATE finished"
		
		i=1
		#rows = ((138450,),)
		conn.commit()
		print "*** COMMIT ***"
		cur.close()
		conn.close()
		print "Connection closed (-)" 
		print "Processing time: "+str(datetime.now()-startTime)
		for row in rows:
			from datetime import datetime
			conn=doConn() #pripojeni k dtb
			startTime = conn[1]
			conn = conn[0]
			cur = conn.cursor()
			
			print "Executing chunk "+str(i)
			row = tuple(row)
			sql = """
				insert into REPLACE_TO_TABLE
				with db as (
				select id_bud_1, id_bud_2, geom
				from (
					select A.id_bud::int as id_bud_1, B.id_bud::int as id_bud_2, (ST_3DIntersection(A.geom, B.geom)) as geom
					from REPLACE_FROM_TABLE A, REPLACE_FROM_TABLE B
					WHERE  A.geom &&& B.geom = 't' and A.id_bud>B.id_bud
					and A.id_bud IN %s
					--GROUP BY 1,2,3
					)foo
				) --END OF WITH CLAUSE
				SELECT id_bud_1, id_bud_2, CASE
					WHEN ST_IsEmpty(geom) THEN -1
					WHEN lower(ST_GeometryType(geom)) like '%%point%%' THEN 0
					WHEN lower(ST_GeometryType(geom)) like '%%linestring%%' THEN 1
					WHEN lower(ST_GeometryType(geom)) like '%%tin%%' THEN 2
					WHEN lower(ST_GeometryType(geom)) like '%%triangle%%' THEN 2
					WHEN lower(ST_GeometryType(geom)) like '%%polygon%%' THEN 2
					WHEN lower(ST_GeometryType(geom)) like '%%polyhedralsurface%%' THEN 3
					ELSE null END as topo_element_dim, lower(ST_GeometryType(geom)) as geomtype
				FROM (
					SELECT id_bud_1, id_bud_2, geom FROM db WHERE lower( ST_GeometryType(geom) ) <> 'st_geometrycollection' OR ST_IsEmpty(geom)='t'
					UNION ALL
					SELECT id_bud_1, id_bud_2, (ST_Dump(geom)).geom as geom FROM db WHERE lower( ST_GeometryType(geom) ) = 'st_geometrycollection'
				)foo
				GROUP BY 1,2,3,4
				;
			"""
			sql = sql.replace("REPLACE_FROM_TABLE", fromTable)
			sql = sql.replace("REPLACE_TO_TABLE",   toTable)
			
			try:
				cur.execute(sql, (row, ) )
				print "  -  OK ( id: " + str(row) + ")"
			except:
				print "  - Failed at id: " + str(row)
				print "  - Trying againL"
				del conn, cur
				conn=doConn() #pripojeni k dtb
				startTime = conn[1]
				conn = conn[0]
				cur = conn.cursor()
				cur.execute(sql, (row, ) )
				pass
			else:
				conn.commit()
				print "*** COMMIT ***"
				cur.close()
				conn.close()
			i=i+1