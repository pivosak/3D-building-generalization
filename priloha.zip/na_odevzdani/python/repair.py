print "***************************************************"
print "****** Model repair *******************************"
print "***************************************************"
def repair(inputTable,targetTable):
	from helpers import *
	from datetime import datetime
	import copy
	sql=""" with db as (select * from """+inputTable+""" )
		select A.id_bud, zmin, zmax, ST_AsText(ST_Union(geom)) as geom from (
		select id_bud, ST_MakeValid(ST_Force2D(geom)) as geom from db) A
		JOIN (select id_bud, MAX(ST_ZMax(geom)) as zmax, MIN(ST_ZMin(geom)) as zmin
			from db group by 1) B ON A.id_bud=B.id_bud GROUP BY 1,2,3 ; """
	conn=doConn() #pripojeni k dtb
	startTime = conn[1]
	conn = conn[0]
	cur = conn.cursor()
	cur.execute(sql) #dotaz na zdrojova data
	rows = cur.fetchall()
	dropTable(cur, targetTable)
	cur.execute("CREATE TABLE "+targetTable+" (id_bud int, geom geometry);")
	for row in rows:
		id = int(row[0])
		polygons = []
		base = parse2Dpoly(row[3]) #parsuj zdrojova data
		#pokud orientace nesmeruje negativne, udelej inverzi
		if ( orientation(base) == 1):
			base = base[::-1]
		zmin = float(row[1]) #zapamatuj si vysku zakladu
		zmax = float(row[2]) #zapamatuj si vysku strechy
		basePoly = copy.deepcopy(base) #zaklad budovy
		for v in basePoly:
			v.append(zmin)
		polygons.append(listToPolyZ(basePoly))
		i=0
		#prochazej dvojice 
		for coor in base:
			v1 = base[i]
			v2 = base[i+1]
			#generuj zdi budovy
			wallPoly = liftUp(base[i],base[i+1],zmin,zmax)
			wallPoly = listToPolyZ(wallPoly)
			polygons.append(wallPoly)
			i+=1
			if (i+1)==len(base):
				break
		roofPoly = copy.deepcopy(base[::-1]) #strecha budovy
		for v in roofPoly:
			v.append(zmax)
		polygons.append(listToPolyZ(roofPoly))
		for p in polygons:
			sql="INSERT INTO "+targetTable+" (id_bud, geom) VALUES ("+str(id)+", ST_GeomFromText('"+p+"'));"
			cur.execute(sql) #uloz orientovave polygony do dtb
	conn.commit()
	print "*** COMMIT ***"
	cur.close()
	conn.close()
	print "Connection closed (-)" 
	print "Processing time: "+str(datetime.now()-startTime)

#RUN repair
#repair("source_table_name","target_table_name")
