﻿print "***************************************************"
print "****** Make HTML file with X3D vizualization *******"
print "***************************************************"
print ""
from helpers import *
from datetime import datetime
conn=doConn() #pripojeni k dtb
startTime = conn[1]
conn = conn[0]
cur = conn.cursor()


partOne = """
<!DOCTYPE html >
<html >
	<head>
        <meta http-equiv="X-UA-Compatible" content="chrome=1" />
		<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
		<title>Hello World</title>
        <link rel="stylesheet" type="text/css" href="x3dom.css" />
		<script type="text/javascript" src="x3dom.js"></script>
	</head>
       
<body>

<x3d style="width:100%; height: 100%;" xmlns="http://www.x3dom.org/x3dom" showStat="false" showLog="false" x="0px" y="0px" altImg="helloX3D-alt.png">
	<scene DEF='scene'>
	<Viewpoint position="-742348.24490 -1046614.72740 356.63500" orientation="0.50021 0.49267 0.71209 1.88583" 
	zNear="28.99759" zFar="1010.26616" description=""></Viewpoint>
"""

'''
cela scena
<Viewpoint position="-742646.11199 -1046147.13391 396.14169" orientation="0.08715 0.52734 0.84517 2.78766" 
	zNear="28.99759" zFar="1010.26616" description=""></Viewpoint>

detail
<Viewpoint position="-742348.24490 -1046614.72740 356.63500" orientation="0.50021 0.49267 0.71209 1.88583" 
	zNear="28.99759" zFar="1010.26616" description=""></Viewpoint>
'''

partTwo = """
	</scene>
</x3d>
<button onclick="document.getElementById('front').setAttribute('set_bind','true');">Front</button>
<button onclick="document.getElementById('neco').setAttribute('set_bind','true');">neco </button>

</body>
</html>
"""

### LOAD X3D DATA ###
sql = """
select ST_AsX3D(geom) as geom from SOURCE_TABLE_NAME;
"""

cur.execute(sql)
rows = cur.fetchall()

shapePart = ""
for row in rows:
	newShape = ""
	newShape += "<shape>"
	newShape += "<appearance><material diffuseColor='0.903 0.294 0.309' ></material></appearance>"
	newShape += row[0].replace("<IndexedFaceSet", "<IndexedFaceSet convex='false'")
	newShape += "</shape>"
	newShape += "\n"
	shapePart += newShape
	
html = partOne + shapePart + partTwo

f = open('html/vizu.html', 'w')
f.write(html)
f.close()




conn.commit()
print "*** COMMIT ***"
cur.close()
conn.close()
print "Connection closed (-)" 
print "Processing time: "+str(datetime.now()-startTime)