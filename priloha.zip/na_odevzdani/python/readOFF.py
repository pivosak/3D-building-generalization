print "***************************************************"
print "****** Object File Format Reader to PostGIS *******"
print "***************************************************"
print ""

from helpers import *
from datetime import datetime
conn=doConn() #pripojeni k dtb
startTime = conn[1]
conn = conn[0]
cur = conn.cursor()


## inputPath - directory with source OFF files (/path/to/directory/)
## writeToTable - name of the dtb table to write into (string)
## elementSize - size of the used structure elemtn (decimal)
def readOFF( inputPath, writeToTable, elementSize):
	print "Reading OFF files from path: " + inputPath
	print "Writing data to file: " + inputPath
	sql = "DROP TABLE IF EXISTS " + writeToTable + ";"
	cur.execute(sql)
	sql = "CREATE TABLE " + writeToTable + " (id_bud int, element_size decimal(10,2), cnt_vertex int, cnt_edge int, cnt_face int, folder varchar(100), geom geometry);"
	cur.execute(sql)
	dir = inputPath ##should be full path
	#read files from specified directory
	import glob, os
	os.chdir(dir)
	for file in glob.glob("*.off"):
		#print(file)

		fullpath = dir + file
		print "Cesta k souboru: " + fullpath
		f = open(fullpath, 'r')
		
		id = str(file.split('.')[0])
		
		iter = 0
		vertexes = []
		facets = []
		for line in f:
			if (iter == 1):
				#print line
				attr = line.split(" ")
				cntVertex =int( attr[0] )
				cntFacet = int( attr[1] )
			
			if (iter > 1):
				#indexes on rows in OFF file
				firstLine = 3
				firstLineFacets = firstLine + cntVertex
				lastLineFacets = firstLineFacets + cntFacet - 1
				#save vertexes to list
				if ( iter >= firstLine and iter < firstLineFacets ):
					vertex = line.split(" ")
					vertex_float = []
					for coor in vertex:
						vertex_float.append( float(coor) )
					
					vertexes.append(vertex_float)
				
				#save facets to list	
				if ( iter >= firstLineFacets and iter <= lastLineFacets ):
					facetline = line.split("  ")  ##first delimiter is double space
					facet = facetline[1].split(" ")  ##second delimiter in single space
					facet_int = []
					for link in facet:
						facet_int.append( int(link) )
					facet_int.append(facet_int[0])
					
					facets.append(facet_int)
			iter += 1;
			
		print "Vertex count: " + str(cntVertex)
		print "Facet count: " + str(cntFacet)
		print "*********************************************************************"
		#print vertexes
		print "*********************************************************************"
		#print facets

		#Build WKT of POlyhedron
		wkt = "POLYHEDRALSURFACE Z ("
		end = ")"
		polygons = ""
		for facet in facets:
			polygon = "(("
			for vertex in facet:
				x = str(vertexes[vertex][0])
				y = str(vertexes[vertex][1])
				z = str(vertexes[vertex][2])
				polygon += x + " " + y + " " + z + ","
			polygon = polygon[:-1]
			polygon += ")),"
			polygons += polygon

		polygons = polygons[:-1]
		wkt = "POLYHEDRALSURFACE Z (" + polygons + ")"
		sql = "INSERT INTO " + writeToTable + " (id_bud,element_size,cnt_vertex,cnt_face,folder,geom) VALUES ('" + id + "', '" + str(elementSize) + "', '" + str(cntVertex) + "', '" + str(cntFacet) + "', '" + str(inputPath) + "', ST_MakeSolid('" + wkt + "') );"
		cur.execute(sql)
####################################################################

		
#RUN reading		
# readOFF("/home/output_2/", "b_2", 2.0)

conn.commit()
print "*** COMMIT ***"
cur.close()
conn.close()
print "Connection closed (-)" 
print "Processing time: "+str(datetime.now()-startTime)
