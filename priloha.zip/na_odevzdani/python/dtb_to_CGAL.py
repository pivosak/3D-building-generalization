########################################################################
####### Export geometry from database to CGAL vectors

#sourceTable =  table with source PolyhedralSurface models
#targetDirectory = directory where to write CGAL vectors
def dtbToCGALvector(sourceTable,targetDirectory):
	from helpers import *
	from datetime import datetime
	sql = """
		DROP TABLE IF EXISTS temp_tocgal_vertex;
		CREATE TABLE temp_tocgal_vertex AS
		SELECT id_bud, ST_X(geom) as x, ST_Y(geom) as y, ST_Z(geom) as z, ((row_number() OVER(PARTITION BY id_bud ORDER BY 1,2,3))::int - 1)::int as vertex_id from (
			SELECT id_bud, (ST_DumpPoints(geom)).geom as geom from """ +sourceTable+ """
		)foo
		GROUP BY 1,2,3,4
		;
		"""
	conn=doConn() #pripojeni k dtb
	startTime = conn[1]
	conn = conn[0]
	cur = conn.cursor()
	
	cur.execute(sql)
	sql = "SELECT x,y,z, id_bud FROM temp_tocgal_vertex order by id_bud"
	cur.execute(sql)
	rows = cur.fetchall()
	vertexArr = "{"
	i=0
	for row in rows:
		if (i>0 and rows[i][3] != rows[i-1][3] ):
			vertexArr += "}\n,{"
		vertexArr += "{"
		vertexArr += str(row[0]) + ","
		vertexArr += str(row[1]) + ","
		vertexArr += str(row[2])
		vertexArr += "},"
		i += 1
	vertexArr += "}"
	print "\n*** VERTEXES ***************************\n"
	#print vertexArr
	f = open(targetDirectory+'/vertexes.txt', 'w')
	vertexArr = vertexArr.replace('\n', '')
	f.write(vertexArr)
	f.close()


	sql ="SELECT id_bud FROM " +sourceTable+ " ORDER BY id_bud;"
	cur.execute(sql)
	target = cur.fetchall()
	print "\n*** IDs ***************************\n"

	ids= ""
	for bud in target:
		ids += "{" + str(bud[0]) + "},"

	f = open(targetDirectory+'/ids.txt', 'w')
	f.write(ids)
	f.close()

		
	print "\n*** FACETS ***************************\n"
	allFacet = ""
	for bud in target:
		
		sql = """
			SELECT facet_id, vertex_id, vertex_order, A.id_bud FROM (
			SELECT id_bud, (gd).path[1] AS facet_id, (gd).path[3] as vertex_order, MAX((gd).path[3]) OVER (PARTITION BY id_bud, (gd).path[1] ) as max_vertex_order, ST_X((gd).geom) as x,  ST_Y((gd).geom) as y,  ST_Z((gd).geom) as z
			FROM (
			SELECT id_bud, ST_DumpPoints(geom) as gd from """ +sourceTable+ """
			where id_bud = %s
			)foo
			)A
			JOIN temp_tocgal_vertex B ON A.x=B.x and A.y=B.y and A.z=B.z AND A.id_bud=B.id_bud
			WHERE vertex_order < max_vertex_order
			ORDER BY A.id_bud, facet_id, vertex_order
			;
			"""
		cur.execute(sql, (bud,) )
		rows = cur.fetchall()
		facetArr = "{"
		facetArr += "{"
		i=0
		for row in rows:
			if (i>0 and rows[i][0] != rows[i-1][0] ): ## check if facets is still the same
				facetArr += "},{"
			facetArr += str( row[1] ) + "," #print vertex ID on position 1
			i += 1
		facetArr += "},"
		facetArr += "},"
		allFacet += facetArr 
		#print facetArr
	f = open(targetDirectory+'/facets.txt', 'w')
	f.write(allFacet)
	f.close()
	
	conn.commit()
	print "*** COMMIT ***"
	cur.close()
	conn.close()
	print "Connection closed (-)" 
	print "Processing time: "+str(datetime.now()-startTime)
	
	
#RUN export to CGAL vector structures
dtbToCGALvector("vizu_orig","input_cgal")


