def ClusterNeighbours(rows):
	delka=0
	flat = []
	for row in rows:
		for item in row:
			flat.append(item)
	aim = len( list(set(flat)) )
	
	#init empty list of aggregations
	agg = []
	agg.append(list(set(rows[0])))
	
	n=0
	while True:
		if (n>0):
			rows = agg
			agg=[]
			agg.append(list(set(rows[0])))
		
		for input in rows:
			#remove duplicates
			input = list(set(input))
			
			#cycle through aggregations
			isnew = True
			pos = -1
			for group in agg:
				pos = pos+1
				S1 = set(input)
				S2 = set(group)
				I = S1.intersection(S2)
				if (len(I) > 0 ):
					#there is an intersection
					isnew = False
					for value in input:
						if (value not in agg[pos]):
							agg[pos].append(value)
					break
			if (isnew):
				new = []
				for value in input:
					new.append(value)
				agg.append(new)
				
		n=n+1
		count=0
		for row in agg:
			count = count + len(row)
		print "Pruchod"
		if (count == aim):
			break
	
		print agg
	
	length=0
	for row in agg:
		length = length + len(row)
	print "Count of unique buildings: "+str(length)
	return agg
	
	
########################################################################
####### Find all touching geometries and cluster it into group
from helpers import *
from datetime import datetime
conn=doConn() #pripojeni k dtb
startTime = conn[1]
conn = conn[0]
cur = conn.cursor()

sourceTable = "vizu_orig"
sourceRelations = "vizu_orig_relations"


print "\n*** GROUPS ***************************\n"
sql = """	select id_bud_1, id_bud_2 from """+sourceRelations+""" where topo_element_dim=2
			union
			select id_bud as id_bud_1, id_bud as id_bud_2 from """+sourceTable+""";
	"""
cur.execute(sql)
rows = cur.fetchall()
merge = ClusterNeighbours(rows)
##save results of merge into database
sql = "CREATE TABLE "+sourceTable+"_agg_lookup (id_agg int, id_bud int);"
cur.execute(sql)

for group in merge:
	for member in group:
		sql = 	"""
				INSERT INTO """+sourceTable+"""_agg_lookup (id_agg, id_bud)
				VALUES ('""" + str(group[0]) + """','""" + str(member) + """');
				"""
		#cur.execute(sql)
		
groups = str(merge).replace('[','{').replace(']','}')
f = open('input_cgal/groups.txt', 'w')
f.write(groups)
f.close()


conn.commit()
print "*** COMMIT ***"
cur.close()
conn.close()
print "Connection closed (-)" 
print "Processing time: "+str(datetime.now()-startTime)