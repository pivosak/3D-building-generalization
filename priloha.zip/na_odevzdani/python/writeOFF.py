print "***************************************************"
print "****** Writer from PostGIS to OFF file ************"
print "***************************************************"
print ""
from helpers import *
from datetime import datetime
conn=doConn() #pripojeni k dtb
startTime = conn[1]
conn = conn[0]
cur = conn.cursor()

###############################
sourceTable = "models"
targetDir = sourceTable
###############################






#import os
#import sys
src=sourceTable
if not os.path.exists(targetDir):
	os.makedirs(targetDir)

##Get list of unique IDs
sql = "SELECT DISTINCT id_bud from " + src + ";"
cur.execute(sql)
rows = cur.fetchall()
cntAll = len(rows)
i=1
for id in rows:
	id = id[0]
	dropTable(cur, "writeoff_geom_dump")
	sql = """
		CREATE TEMPORARY TABLE writeoff_geom_dump AS
		select id, ST_X(geom) as x, ST_Y(geom) as y, ST_Z(geom) as z, pnt_order from (
		select ring as id, geom, MAX(pnt_order) OVER (PARTITION BY ring) as max_order, pnt_order from (
		select id_bud as id, (ST_DumpPoints(geom)).path[1] as ring, (ST_DumpPoints(geom)).path[3] as pnt_order, (ST_DumpPoints(geom)).geom as geom 
		from """+ src +""" where id_bud= '""" + str(id) +"""'
		)foo
		)foo WHERE pnt_order < max_order
		;
	"""
	cur.execute(sql)

	### VERTEX PART ###
	dropTable(cur, "writeoff_unique_vertex")
	sql = """
		CREATE TEMPORARY TABLE writeoff_unique_vertex AS
		select x, y, z, ((row_number() OVER(ORDER BY 1,2,3))-1)::int as vertex_link from (
			SELECT x, y, z from writeoff_geom_dump group by 1,2,3
		)foo
		;
	"""
	cur.execute(sql)

	sql = "SELECT vertex_link, x, y, z from writeoff_unique_vertex;"
	cur.execute(sql)
	rows = cur.fetchall()


	vertexPart = ""
	vertexCnt = 0
	for row in rows:
		newline = str(row[1]) + " " + str(row[2]) + " " + str(row[3])
		newline = newLine(newline)
		vertexPart += newline
		vertexCnt +=1

		
	### FACE PART ###
	sql = """
		SELECT id, vertex_link
		FROM writeoff_geom_dump A
		JOIN writeoff_unique_vertex B ON A.x=B.x and A.y=B.y and A.z=B.z
		ORDER BY id, pnt_order
	"""
	cur.execute(sql)
	rows = cur.fetchall()

	previousID = None
	faces = []
	face = []
	#prepare easily readable strucutre
	for vertex in rows:
		#print str(vertex[0]) + " | " + str(vertex[1])
		if ( vertex[0] != previousID and len(face)>0  ):
			faces.append(face)
			face = []
		face.append( vertex[1] )
		previousID = vertex[0]
	faces.append(face)
		
	facesPart = ""
	facesCnt = 0
	for face in faces:
		line = str(len(face)) + " "
		for link in face:
			line += " " + str(link)
		line = newLine(line)
		facesPart += line
		facesCnt += 1

		
	off = "OFF"
	off = newLine(off)
	off += str(vertexCnt) + " " + str(facesCnt) + " 0"
	off = newLine(off)
	off = newLine(off)	
	off += vertexPart
	off += facesPart

	f = open(targetDir+'/'+str(id)+'.off', 'w')
	f.write(off)
	f.close()
	
	m = int(round(i/cntAll*100))
	sys.stdout.write("\rDoing thing %i" % m)
	sys.stdout.flush()
	i+=1



conn.commit()
print "*** COMMIT ***"
cur.close()
conn.close()
print "Connection closed (-)" 
print "Processing time: "+str(datetime.now()-startTime)
