print "***************************************************"
print "****** Build topology procedure *******************"
print "***************************************************"

#targetTable = name of the table, where to build topology
#targetTable must have this structure: (id_bud int, geom geometry)
def BuildTopology(targetTable):
	t = targetTable
	from helpers import *
	from datetime import datetime
	conn=doConn() #pripojeni k dtb
	startTime = conn[1]
	conn = conn[0]
	cur = conn.cursor()
	
	sql = "DROP INDEX IF EXISTS "+t+"_index ;"
	print sql
	cur.execute(sql)
	
	sql = "CREATE INDEX "+t+"_index ON "+t+" USING GIST ( geom ) ;"
	print sql
	cur.execute(sql)
	
	sql = "DROP FUNCTION "+t+"_topo() CASCADE;"
	print sql
	cur.execute(sql)
	
	sql = """
	CREATE FUNCTION """+t+"""_topo() RETURNS trigger AS $"""+t+"""_topo$
	DECLARE
		r int;
		i int := 0;
    BEGIN
		
		DROP TABLE IF EXISTS """+t+"""_relations;
        CREATE TABLE """+t+"""_relations (id_a int, id_b int, dimension int);
		
		FOR r IN SELECT id_bud FROM """+targetTable+"""
		LOOP
			i := i + 1;
			INSERT INTO """+t+"""_relations (id_a, id_b, dimension)
			SELECT
				A. id_bud as ID_a ,
				B. id_bud as ID_b ,
				ST_Dimension ( ( ST_3DIntersection (A. geom, B. geom) ) ) as dimension
			FROM """+t+""" as A, """+t+""" as B
			WHERE
				A. geom && A.geom = 't' and A.id_bud>B.id_bud
				AND A.id_bud=r;
			RAISE NOTICE 'id (%) done (%)', r,i;
		END LOOP;
		RETURN NEW;
    END;
	$"""+t+"""_topo$ LANGUAGE plpgsql;
	"""
	print sql
	cur.execute(sql)
	
	sql = """
	CREATE TRIGGER """+t+"""_topo AFTER INSERT OR UPDATE OR DELETE OR TRUNCATE ON """+targetTable+"""
    FOR EACH STATEMENT EXECUTE PROCEDURE """+t+"""_topo();
	"""
	print sql
	cur.execute(sql)
	
	######################
	conn.commit()
	print "*** COMMIT ***"
	cur.close()
	conn.close()
	print "Connection closed (-)" 
	print "Processing time: "+str(datetime.now()-startTime)
	
	
	
#BUILD topology a check topoplogy relations
BuildTopology("testingtopo");