﻿Struktura prilohy
- cplusplus 	#zdrojove cody C++
- db			#dump databaze 
- modely		#modely v OFF formatu
- python		#zdrojove kody Python
- vizualizace	#HTML vizualizace