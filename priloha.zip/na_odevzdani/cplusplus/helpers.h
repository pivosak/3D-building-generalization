#include <CGAL/Exact_predicates_exact_constructions_kernel.h>
#include <CGAL/Exact_integer.h>
#include <CGAL/Homogeneous.h>
#include <CGAL/IO/Polyhedron_iostream.h>
#include <CGAL/Nef_polyhedron_3.h>
#include <CGAL/IO/Nef_polyhedron_iostream_3.h>
#include <CGAL/Polyhedron_incremental_builder_3.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/minkowski_sum_3.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/boost/graph/graph_traits_Polyhedron_3.h>
#include <CGAL/Polygon_mesh_processing/triangulate_hole.h>

#include <math.h>
#include <iostream>
#include <exception>
#include <fstream>
#include <vector>
#include <boost/foreach.hpp>
#include <algorithm>

#include <istream>
#include <string>
#include <sstream>

typedef CGAL::Exact_predicates_exact_constructions_kernel Kernel;

typedef CGAL::Polyhedron_3<Kernel>  Polyhedron;
typedef CGAL::Nef_polyhedron_3<Kernel> Nef_polyhedron;
typedef Kernel::Vector_3  Vector_3;
typedef Kernel::Aff_transformation_3  Aff_transformation_3;
typedef Kernel::Point_3                              Point_3;
typedef CGAL::Polyhedron_3<Kernel>                   Polyhedron; //tohle jsme tu mel puvodne
typedef Polyhedron::Facet_iterator                   Facet_iterator;
typedef Polyhedron::Halfedge_around_facet_circulator Halfedge_facet_circulator;
typedef Polyhedron::Halfedge_handle                 Halfedge_handle;
typedef Polyhedron::Facet_handle       Facet_handle;
typedef Polyhedron::Vertex_handle      Vertex_handle;

/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////
typedef std::vector<Point_3>			vectorPoint;
typedef CGAL::Segment_3<Kernel>			Segment_3;

///Credit for this helper functions goes to https://github.com/tudelft3d

vectorPoint get_facetPoints(Polyhedron::Halfedge_handle& heH) {
	Polyhedron::Facet::Halfedge_around_facet_circulator itHDS = heH->facet_begin();
	vectorPoint facetPnts;
	do facetPnts.push_back(itHDS->vertex()->point());
	while (++itHDS != heH->facet_begin());
	return facetPnts;
}

bool checkForHoles (Polyhedron::Halfedge_handle& heH) {
	vectorPoint otherFacetPnts = get_facetPoints(heH);

	Polyhedron::Halfedge_around_facet_circulator hafIt = heH->opposite()->facet_begin();
	bool nextNotBorder	= false;
	bool difFound		= false;
	bool refound		= false;
	bool canJoinFacets	= true;
	do {
		if (difFound ^ nextNotBorder) {
			if (refound) {
				canJoinFacets=false;
				break;
			}
			refound		=  difFound;
			difFound	= !difFound;
		}
		nextNotBorder = heH->facet() != hafIt->next()->opposite()->facet();
		if (difFound && nextNotBorder &&
			std::find(otherFacetPnts.begin(), otherFacetPnts.end(),hafIt->vertex()->point())!=otherFacetPnts.end()) {
				canJoinFacets=false;	
				break;
		}
	} while (++hafIt != heH->opposite()->facet_begin());
	return canJoinFacets;
}


bool noIntersection (Polyhedron::Halfedge_handle heH, bool isOpposite) {

	Segment_3 checkSeg (heH->vertex()->point(),heH->prev()->prev()->vertex()->point());	
	Polyhedron::Halfedge_around_facet_circulator hafIt = heH->facet_begin()++;			// skip itself and first

	while (++hafIt != heH->prev()->facet_begin()) {
		if (CGAL::do_intersect(checkSeg,Segment_3(hafIt->vertex()->point(),hafIt->prev()->vertex()->point())))
			return false;
	} 
	if (!isOpposite)
		return noIntersection (heH->opposite(), true);
	else
		return true;
}
bool noIntersection (Polyhedron::Halfedge_handle heH, bool isOpposite=false);


bool normalizeVector(Vector_3& vec) {
	double length = sqrt(CGAL::to_double(vec.squared_length()));
	if (length==0) return false;
	vec = vec/length;
	return true;
}

double comp_angle(Vector_3 vec1,Vector_3 vec2) {
	if (!normalizeVector(vec1) || !normalizeVector(vec2)) {
		return -1;
	}
	double theta;
	double scalarProd = CGAL::to_double(vec1*vec2);
	if		(scalarProd>1)	theta = 0;
	else if (scalarProd<-1)	theta = CGAL_PI;
	else theta = abs(acos(scalarProd)); 
	return theta;
}

typedef Kernel::Direction_3				Direction_3;
bool isColinear(Direction_3& dir1,Direction_3& dir2) {
	if (dir1==dir2) return true;
	else return false;
}
#define ANGLE_LIMIT			0.0001

bool isColinear(Vector_3& normal1,Vector_3& normal2, double angleThresh) {
	if (angleThresh>=0)
		return comp_angle(normal1,normal2) < angleThresh;
	else
		return comp_angle(normal1,normal2) < ANGLE_LIMIT;
}
bool isColinear(Vector_3& normal1,Vector_3& normal2, double angleThresh=-1);



void Col(Polyhedron& p) {
	int vertBefore =  p.size_of_vertices();
	bool colinearFound = true;
	while (colinearFound) {
		colinearFound = false;

		int percCount = 1;
		for (Polyhedron::Halfedge_iterator hit = p.halfedges_begin(); hit != p.halfedges_end(); ++hit,++percCount){
			if (CGAL::circulator_size(hit->vertex_begin()) == 1) {
				while (CGAL::circulator_size(hit->vertex_begin()) == 1)
					hit = p.join_vertex(hit->opposite());
				break;
			}

			if ((CGAL::circulator_size(hit->vertex_begin()) == 2) &&
				(hit->facet_degree()>3 && hit->opposite()->facet_degree()>3)) {

				Vector_3 cur(hit->prev()->vertex()->point(),hit->vertex()->point());
				Vector_3 nex(hit->vertex()->point(),hit->next()->vertex()->point());
				if ( isColinear(cur,nex)) {									
					p.join_vertex(hit->opposite());								
					colinearFound = true;
					break;
	}	}	}	}
	
}

struct compNormal {	// only for convex facets
    template <class Facet>
    typename Facet::Plane_3 operator()( Facet& f) {
        typename Facet::Halfedge_handle h = f.halfedge();
        typedef typename Facet::Plane_3  Plane;
        return Plane( h->vertex()->point(),
                      h->next()->vertex()->point(),
                      h->next()->next()->vertex()->point());
    }
};

bool isCoplanar(Polyhedron::Halfedge_handle heH, bool checkSem) {
	Vector_3 normal1 = heH->face()->plane().orthogonal_vector();
	Vector_3 normal2 = heH->opposite()->face()->plane().orthogonal_vector();
	return isColinear(normal1,normal2);
}